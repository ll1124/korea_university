#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<Windows.h>
#define TIMES 3

char printHeader();
long double comDiceRollingAndBet(long double *cash, int *sumOfDice, int *comDice);
char userDiceRolling(long double *cash, long double *bet, int *sumOfDice, int *comDice, int *userDice);
char compareDice(long double *cash, long double *bet, int *comDice, int *userDice, int *wins, int *loses);
void drawDice(int _i, int _number);

int main(void) {

	int input;
	long double cash = 100000;
	int wins = 0;
	int loses = 0;
	long double bet;
	int sumOfDice = 0;
	int comDice[3];
	int userDice[3];
	char tempForDecision;

	srand(time(NULL));

	do
	{
		input = printHeader(); // print main menu

		if (input == 49) { //1. print my state
			system("cls");
			printf("Current Cash: %.0Lf\n", cash);
			printf("Wins: %d\n", wins);
			printf("Loses: %d\n\n", loses);
			printf("Type any key to go main menu...");
			_getch(); // after user input go back to main menu
			system("cls");
		}
		else if (input == 50) { //2. dice rolling game
			
			if (cash <= 0) //when cash is zero or minus, can't start game
			{
				system("cls");
				printf("You don't have enough cash to start\nType any key to go main menu...");
				_getch();
				system("cls");
			}
			else
			{
				do
				{
					do
					{
						system("cls");
						bet = comDiceRollingAndBet(&cash, &sumOfDice, comDice); // computer dice rolling
						system("cls");
						if (cash >= 5000) // start game, cash >= 5000, have surrender option
						{
							do
							{
								tempForDecision = userDiceRolling(&cash, &bet, &sumOfDice, comDice, userDice);
								system("cls");
							} while (tempForDecision != 27 && tempForDecision != 's');
						}
						else // cash < 5000, can't surrender
						{
							do
							{
								tempForDecision = userDiceRolling(&cash, &bet, &sumOfDice, comDice, userDice);
								system("cls");
							} while (tempForDecision != 27);
						}
						system("cls");
						if (tempForDecision == 's') // surrender
						{
							loses += 1;
							cash -= 5000;
						}
					} while (tempForDecision == 's');
					if (tempForDecision == 27) // compare dice
					{
						tempForDecision = compareDice(&cash, &bet, comDice, userDice, &wins, &loses);
						system("cls");
					}
					if (cash <= 0 && tempForDecision == 49) // if cash <= 0, can't retry the game
					{
						system("cls");
						printf("You don't have enough cash to start\nType any key to go main menu...");
						_getch();
						break;
					}
				} while (tempForDecision == 49);
			}
		}
		else if (input == 51) { // 3. end
			return 0;
		}
	} while (1);
}

char printHeader() {

	int input;

	do { // print main menu
		system("cls");
		printf("1.My State\n");
		printf("2.Dice Rolling Game\n");
		printf("3.End\n\n");
		printf("Enter your choice : ");
		input = getchar();// user input
		while (getchar() != '\n');
	} while (input != 49 && input != 50 && input != 51); // print until input is 1,2 or 3

	return input;
}

long double comDiceRollingAndBet(long double *cash, int *sumOfDice, int *comDice) {

	int i;
	long double bet;

	(*sumOfDice) = 0;

	printf("Current cash : %.0Lf\n\n", *cash);

	for (i = 0; i < TIMES; i++) // comdice rolling
	{
		*(comDice + i) = rand() % 6 + 1;
		(*sumOfDice) += *(comDice + i);
	}
	
	printf("Sum of computer's dices : %d\n\n", *sumOfDice);

	do // bet cash
	{
		bet = 0;
		printf("Input your betting : ");
		scanf_s("%Lf", &bet);
		while (getchar() != '\n'); 
		if (bet > *cash)
		{
			printf("Betting money is larger than your total cash\n");
		}
		if (bet <= 0) 
		{
			printf("You should bet more than 0\n");
		}
	} while (!(bet > 0 && bet <= *cash));

	return bet;
}

char userDiceRolling(long double *cash, long double *bet, int *sumOfDice, int *ComDice, int *userDice)
{
	
	int tempDiceSum;
	int tempDice;
	int i, j;
	char tempForDecision;

	tempDiceSum = *sumOfDice;
	for (i = 0; i < TIMES; i++) // user dice rolling
	{
		if (i == 2) // third user dice
		{
			*(userDice + i) = tempDiceSum;
			tempDiceSum = 0;
		}
		else // first, second user dice
		{
			tempDice = rand() % 6 + 1;
			if (tempDice + 2 - i <= tempDiceSum) // set maximum dice number
			{
				if (tempDiceSum - (tempDice + 6 * (2 - i)) <= 0) // set minimum dice number
				{
					*(userDice + i) = tempDice;
					tempDiceSum -= tempDice;
				}
				else
				{
					i--;
					continue;
				}
			}
			else
			{
				i--;
			}
		}
	}
	printf("Computer's dice total is %d\n", *sumOfDice);

	for (i = 1; i <= 5; i++) // draw dice boader for com
	{	
		for (j = 0; j < TIMES; j++)
		{
			drawDice(i, 0);
		}
		putchar('\n');
	}

	for (i = 1; i <= 5; i++) // draw user dice
	{
		for (j = 0; j < TIMES; j++)
		{
			drawDice(i, *(userDice + j));
		}
		putchar('\n');
	}

	if (*cash < 5000) // cash < 5000, can't surrender
	{
		printf("Type ESC to Start Game\n");
		printf("Any key. Rolling dice again\n");
		printf("You can't surrender\nYou don't have enough money to surrender\n");
	}
	else
	{
		printf("Type ESC to Start Game\n");
		printf("Type s to Surrender\n");
		printf("Any key. Rolling dice again\n");

	}
	tempForDecision = _getch();
	return tempForDecision;
}

char compareDice(long double *cash, long double *bet, int *comDice, int *userDice, int *wins, int *loses)
{
	int i, j, k;
	int userWinNum = 0;
	char tempForDecision;

	for (i = 0; i < TIMES; i++) //compare dice, stage 1,2 and 3
	{
		system("cls");
		printf("Stage %d\n", i+1);

		for (j = 1; j <= 5; j++)
		{
			for ( k = 0; k < i+1; k++)
			{
				drawDice(j, *(comDice+k));
			}
			putchar('\n');
		}

		for (j = 1; j <= 5; j++)
		{
			for ( k = 0; k < i+1; k++)
			{
				drawDice(j, *(userDice+k));
			}
			putchar('\n');
		}
		if (*(comDice+i) >= *(userDice+i))
		{
			printf("Computer Win\n");
		}
		else
		{
			printf("User Win\n");
			userWinNum += 1;
		}
		Sleep(2000);
	}
	if (userWinNum >= 2) // decide final winner
	{
		printf("Final winner : User!!\n");
		(*cash) += (*bet) * 2;
		(*wins)++;
	}
	else
	{
		printf("Final winner : Computer!!\n");
		(*cash) -= (*bet);
		(*loses)++;
	}

	printf("1. Retry\n");
	printf("2. Back to main menu\n");
	do
	{
		printf("Enter your choice : ");
		tempForDecision = getchar();
		while (getchar() != '\n');
	} while (tempForDecision != 49 && tempForDecision != 50);
	
	return tempForDecision;
}

void drawDice(int _i, int _number)
{
	switch (_i)
	{
	case 1:
		printf("����������");
		break;
	case 2:
		switch (_number)
		{
		case 0:
			printf("��      ��");
			break;
		case 1:
		case 2:
			printf("��      ��");
			break;
		case 3:
			printf("��    �ܦ�");
			break;
		case 4:
		case 5:
		case 6:
			printf("����  �ܦ�");
			break;
		}
		break;
	case 3:
		switch (_number)
		{
		case 0:
			printf("��      ��");
			break;
		case 1:
		case 3:
		case 5:
			printf("��  ��  ��");
			break;
		case 2:
		case 6:
			printf("����  �ܦ�");
			break;
		case 4:
			printf("��      ��");
			break;
		}
		break;
	case 4:
		switch (_number)
		{
		case 0:
			printf("��      ��");
			break;
		case 1:
		case 2:
			printf("��      ��");
			break;
		case 3:
			printf("����    ��");
			break;
		case 4:
		case 5:
		case 6:
			printf("����  �ܦ�");
			break;
		}
		break;
	case 5:
		printf("����������");
		break;
	}
}
